#!/bin/bash

take_sum()
{
   echo $*
   echo $#
}

take_sum 1 2

echo $*
