 #!/bin/sh
 
name="Hello"

echo "$name World"
