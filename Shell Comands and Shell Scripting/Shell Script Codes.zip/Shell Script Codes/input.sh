#!/bin/sh

read name

echo "Yes, your name is $name"
