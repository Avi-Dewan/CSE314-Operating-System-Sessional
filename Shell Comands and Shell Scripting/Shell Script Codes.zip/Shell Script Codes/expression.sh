#!/bin/sh


a=`expr 1 + 1`

b=`expr $a + 10`

c=$(expr 1 + 1)

echo $b $a $c
