#!/bin/sh

echo $*

echo $#

echo $1

echo ${10}




