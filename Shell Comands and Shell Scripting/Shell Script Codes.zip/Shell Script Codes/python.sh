#!/usr/bin/python3

import math

a= int(input())

print(a*a)
